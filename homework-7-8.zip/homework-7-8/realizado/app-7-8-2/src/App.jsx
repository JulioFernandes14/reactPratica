import Botao from "./Botao"
import Imagem from "./Imagem"
import Input from "./Input"

function App() {
  
  return (
    <>
    
      <Botao/>

      <Imagem/>

      <Input/>
    
    </>
  )

}

export default App
