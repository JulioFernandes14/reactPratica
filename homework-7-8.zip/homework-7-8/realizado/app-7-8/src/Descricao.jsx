import './Descricao.css'

function Descricao(props) {
    return (
        <span className="descricao"> {props.descricao} </span>
    )
}

export default Descricao